﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Dataverse.MoveNNRelationship
{
    public class PostContactCreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service

            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider. 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            // Obtain the organization service reference which you will need for 
            // web service calls. 
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                Entity getContactDetails = (Entity)context.InputParameters["Target"];
                if (getContactDetails.Attributes.Contains("originatingleadid"))
                {
                    tracingService.Trace("Plugin Started..");
                    string strFirstEntity = "new_techinterest";
                    string strSecondEntity = "lead";
                    string strRelationshipEntityName = "new_lead_new_techinterest";
                    QueryExpression querys = new QueryExpression(strFirstEntity);
                    querys.ColumnSet = new ColumnSet(true);
                    LinkEntity linkEntity1s = new LinkEntity(strFirstEntity, strRelationshipEntityName, "new_techinterestid", "new_techinterestid", JoinOperator.Inner);
                    LinkEntity linkEntity2s = new LinkEntity(strRelationshipEntityName, strSecondEntity, "leadid", "leadid", JoinOperator.Inner);
                    linkEntity1s.LinkEntities.Add(linkEntity2s);
                    querys.LinkEntities.Add(linkEntity1s);

                    linkEntity2s.LinkCriteria = new FilterExpression();
                    linkEntity2s.LinkCriteria.AddCondition(new ConditionExpression("leadid", ConditionOperator.Equal, ((EntityReference)getContactDetails.Attributes["originatingleadid"]).Id));
                    EntityCollection collRecordss = service.RetrieveMultiple(querys);
                    foreach (var loopCollRecordss in collRecordss.Entities)
                    {
                        EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
                        EntityReference getTechInterestRecord = new EntityReference("new_techinterest", loopCollRecordss.Id);
                        relatedEntities.Add(getTechInterestRecord);
                        Relationship relationship = new Relationship("new_contact_new_techinterest");

                        AssociateRequest requst = new AssociateRequest()
                        {
                            RelatedEntities = relatedEntities,
                            Relationship = relationship,
                            Target = new EntityReference("contact", getContactDetails.Id)
                        };

                        service.Execute(requst);
                        tracingService.Trace("Plugin Ended..");
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {

                throw new InvalidPluginExecutionException(ex.Message.ToString());
            }
        }
    }
}